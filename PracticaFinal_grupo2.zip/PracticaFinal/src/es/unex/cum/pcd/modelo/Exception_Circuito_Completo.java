package es.unex.cum.pcd.modelo;

public class Exception_Circuito_Completo extends Exception {

	private static final long serialVersionUID = 2L;

	public Exception_Circuito_Completo() {
		super();
	}

	public Exception_Circuito_Completo(String msg) {
		super(msg);
	}

	public String getMessage() {
		return "Error, el circuito esta lleno!";
	}
}
