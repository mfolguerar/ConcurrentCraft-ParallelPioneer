package es.unex.cum.pcd.modelo;

//Ignacio Morcillo Pin
public class Incidencia {

	private String nombreIncidencia; //Atributo donde guardamos el nombre de la incidencia, es decir, "Nada, Aceite, Rueda, AccidenteLeve..."
	private int tipoIncidencia; //Este atributo es por si queremos usar 0,1,2,3... en vez del nombre completo "Nada, Aceite, Rueda, AccidenteLeve..."

	public Incidencia() {
		this.nombreIncidencia = generarIncidenciaNombre(); //Las incidencias se generan de manera aleatoria
		this.tipoIncidencia = generarIncidenciaNumero(); //Las incidencias se generan de manera aleatoria
	}

	public String getNombreIncidencia() {
		return nombreIncidencia;
	}

	public void setNombreIncidencia(String nombreIncidencia) {
		this.nombreIncidencia = nombreIncidencia;
	}

	public int getTipoIncidencia() {
		return tipoIncidencia;
	}

	public void setTipoIncidencia(int tipoIncidencia) {
		this.tipoIncidencia = tipoIncidencia;
	}

	private String generarIncidenciaNombre() {

		String tipos[] = {"Nada","Aceite","Rueda","AccidenteLeve"}; //Tipos de incidencia que se pueden producir 

		int aleatorio = (int) (Math.random() * tipos.length); //Generamos el tipo de incidencia de forma aleatoria

		return tipos[aleatorio]; //Devolvemos el nombre de la incidencia de forma aleatoria
	}

	private int generarIncidenciaNumero() {

		//Tipos de incidencias que puede haber: 0-Nada, 1-Aceite, 2-Rueda, 3-AccidenteLeve

		int aleatorio = (int) (Math.random() * 4); //Generamos el tipo de incidencia de forma aleatoria, en este caso de 0-3

		return aleatorio; //Devolvemos el numero al que le corresponde la incidencia generada de forma aleatoria
	}

	@Override
	public String toString() {
		return "Incidencia [nombreIncidencia=" + nombreIncidencia + "]";
	}

}
