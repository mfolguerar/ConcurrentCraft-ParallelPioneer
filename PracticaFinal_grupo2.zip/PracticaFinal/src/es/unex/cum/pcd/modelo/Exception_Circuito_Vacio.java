package es.unex.cum.pcd.modelo;

public class Exception_Circuito_Vacio extends Exception {

	private static final long serialVersionUID = 2L;

	public Exception_Circuito_Vacio() {
		super();
	}
	
	public Exception_Circuito_Vacio(String msg) {
		super(msg);
	}
	
	public String getMessage() {
		return "Error, el circuito esta vacio!";
	}
}