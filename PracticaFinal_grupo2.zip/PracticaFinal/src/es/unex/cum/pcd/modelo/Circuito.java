package es.unex.cum.pcd.modelo;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import es.unex.cum.pcd.practica.Main_Interfaz;

//Ignacio Morcillo Pin
public class Circuito {

	//En cada columna puede haber: Nada, Aceite/Agua(Espera x segundos), Suceso(Se retira de la carrera), Accidente_leve(todos los coches esperan x segundos)

	private Incidencia [][] matriz_coches; //Donde en cada columna tiene un tipo de accidente diferente, y cada fila es por donde circula el coche.
	private Coche[] coches; //Vector donde van a estar los diferentes coches, el tama�o sera igual al numero de filas de la matriz. Asi cada ver que miramos una fila de la matriz, consultamos el mismo indice del vector para saber que coche es el que esta circulando.
	private int num_coches_actual; //Numero de coches que hay en el circuito, actualizando cuando un coche sale o un coche ya termina la carrera 
	private int num_coches_maximo;
	private int filas; //Numero de filas de la matriz que sera el numero maximo de coches que participan en la carrera
	private int columnas; //Numero de columnas de la matriz
	private int tiempoEspera; //Tiempo de espera para el accidente es de 1 segundo
	private boolean comienzoCarrera; //True si ha comenzado la carrera, false si no ha comenzado

	private Lock  lock; // Controla el acceso a la seccion critica
	private Condition lleno; // Condicion para controlar si esta lleno el circuito
	private Condition vacio; // Condicion para controlar si esta vacio el circuito

	private JButton[][] button;
	private JFrame frame_botones;

	public JButton[][] getButton() {
		return button;
	}

	public void setButton(JButton[][] button) {
		this.button = button;
	}

	public JFrame getFrame_botones() {
		return frame_botones;
	}

	public void setFrame_botones(JFrame frame_botones) {
		this.frame_botones = frame_botones;
	}

	public Circuito() {
		//Valores por defecto de filas y columnas
		this.filas = 6;
		this.columnas = 8;
		this.tiempoEspera = 1000; //Tiempo de espera de 1 segundo

		this.matriz_coches = new Incidencia[filas][columnas];
		crearMatriz(); //Rellenamos la matriz
		this.coches = new Coche[filas]; //El tama�o del vector de los coches es el numero de filas de la matriz
		this.num_coches_actual = 0;
		this.num_coches_maximo = filas; //El numero de coches maximo es el numero de filas de la matri	
		this.comienzoCarrera = false;

		this.lock = new ReentrantLock(); // Controla el acceso a la seccion critica
		this.lleno = lock.newCondition(); // Condicion para controlar si esta lleno el circuito 
		this.vacio = lock.newCondition(); // Condicion para controlar si esta vacio el circuito
		
		frame_botones = new JFrame("CIRCUITO");
		frame_botones.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_botones.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame_botones.getContentPane().setLayout(new GridLayout(matriz_coches.length, matriz_coches[0].length+1, 20, 20));
		frame_botones.setTitle("CIRCUITO");
		frame_botones.setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Main_Interfaz.class.getResource("../imagenes/icono_bandera.png")));

		button = new JButton[matriz_coches.length][matriz_coches[0].length+1];

		for (int i = 0; i < matriz_coches.length; i++) {
			for (int j = 0; j < matriz_coches[0].length+1; j++) {
				button[i][j] = new JButton();

				frame_botones.add(button[i][j]);
			}
		}
		
		//Dibujamos la interfaz
		Main_Interfaz.crear_Circuito(getCoches(), getMatriz_coches(), getFrame_botones(), getButton(), getMatriz_coches().length,
				getMatriz_coches()[0].length);
	}

	public Circuito(int nfilas, int ncolumnas) {
		//Valores por defecto de filas y columnas son los que nos pasan
		this.filas = nfilas;
		this.columnas = ncolumnas;
		this.tiempoEspera = 1000; //Tiempo de espera de 1 segundo

		this.matriz_coches = new Incidencia[filas][columnas];
		crearMatriz(); //Rellenamos la matriz
		this.coches = new Coche[filas]; //El tama�o del vector de los coches es el numero de filas de la matriz
		this.num_coches_actual = 0;
		this.num_coches_maximo = filas; //El numero de coches maximo es el numero de filas de la matriz
		this.comienzoCarrera = false;

		this.lock = new ReentrantLock(); // Controla el acceso a la seccion critica
		this.lleno = lock.newCondition(); // Condicion para controlar si esta lleno el circuito 
		this.vacio = lock.newCondition(); // Condicion para controlar si esta vacio el circuito


		frame_botones = new JFrame("CIRCUITO");
		frame_botones.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_botones.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame_botones.getContentPane().setLayout(new GridLayout(matriz_coches.length, matriz_coches[0].length+1, 20, 20));
		frame_botones.setTitle("CIRCUITO");
		frame_botones.setIconImage(Toolkit.getDefaultToolkit()
				.getImage(Main_Interfaz.class.getResource("../imagenes/icono_bandera.png")));

		button = new JButton[matriz_coches.length][matriz_coches[0].length+1];

		for (int i = 0; i < matriz_coches.length; i++) {
			for (int j = 0; j < matriz_coches[0].length+1; j++) {
				button[i][j] = new JButton();

				frame_botones.add(button[i][j]);
			}
		}

		//Dibujamos la interfaz
		Main_Interfaz.crear_Circuito(getCoches(), getMatriz_coches(), getFrame_botones(), getButton(), getMatriz_coches().length,
				getMatriz_coches()[0].length);
	}

	public Incidencia[][] getMatriz_coches() {
		return matriz_coches;
	}

	public void setMatriz_coches(Incidencia[][] matriz_coches) {
		this.matriz_coches = matriz_coches;
	}

	public Coche[] getCoches() {
		return coches;
	}

	public void setCoches(Coche[] coches) {
		this.coches = coches;
	}

	public int getNum_coches_actual() {
		return num_coches_actual;
	}

	public void setNum_coches_actual(int num_coches_actual) {
		this.num_coches_actual = num_coches_actual;
	}

	public int getNum_coches_maximo() {
		return num_coches_maximo;
	}

	public void setNum_coches_maximo(int num_coches_maximo) {
		this.num_coches_maximo = num_coches_maximo;
	}

	public int getFilas() {
		return filas;
	}

	public void setFilas(int filas) {
		this.filas = filas;
	}

	public int getColumnas() {
		return columnas;
	}

	public void setColumnas(int columnas) {
		this.columnas = columnas;
	}

	public int getTiempoEspera() {
		return tiempoEspera;
	}

	public void setTiempoEspera(int tiempoEspera) {
		this.tiempoEspera = tiempoEspera;
	}

	public boolean isComienzoCarrera() {
		return comienzoCarrera;
	}

	public void setComienzoCarrera(boolean comienzoCarrera) {
		this.comienzoCarrera = comienzoCarrera;
	}

	//Metodo para ir recorriendo la matriz e ir rellenando las celdas con un tipo de los 4 incidentes que hay
	public void crearMatriz() {

		for (int fila = 0; fila < filas; fila++) {
			for (int columna = 0; columna < columnas; columna++) {
				matriz_coches[fila][columna] = new Incidencia(); //En cada celda ponemos una nueva incidencia
			}
		}
	}

	//Metodo para mostrar las incidencias de cada celda de la matriz
	public void mostrarMatriz() {

		for (int fila = 0; fila < filas; fila++) {
			for (int columna = 0; columna < columnas; columna++) {
				System.out.print("		"+matriz_coches[fila][columna].getNombreIncidencia());		
			}
			System.out.println();
		}
	}

	//Metodo para contar el numero de coches actual
	public void contar_coche() {

		try {
			lock.lock(); //Bloqueamos el acceso a la seccion critica
			System.out.println("N�mero de coches en circuito "+num_coches_actual);

		} finally {
			lock.unlock(); //Desbloqueamos el acceso a la seccion critica
		}
	}

	//Metodo que simula la entrada de un coche en el circuito
	public void entra_coche(){

		if(comienzoCarrera==false) { //Si no ha comenzado la carrera

			try {
				//**************
				lock.lock(); //Bloqueamos la seccion critica

				while (num_coches_actual == num_coches_maximo) { //Si esta lleno el circuito
					try {
						lleno.await(); //Bloqueamo el proceso porque el circuito esta lleno
					} catch (InterruptedException e) {
					}
				}
				//**************

				boolean insertado = false;

				for(int i=0;i<getCoches().length && !insertado;i++) {

					if(getCoches()[i]==null) { //Si hay un carril libre insertamos el coche
						Coche c = new Coche(i+1, "Mercedes", "V6", 1000, "Negro", 350, i, -1); //La columna siempre sera -1 porque aun no ha entrado en la primera casilla
						getCoches()[i] = c; //A�adimos el coche

						System.out.println("Coche"+c.getIdentificador()+" entra");
						System.out.println("Coche"+c.getIdentificador()+" en la posici�n ("+c.getFila()+","+c.getColumna()+")");

						num_coches_actual = num_coches_actual+1; //Aumentamos el numero de coches que hay actualmente

						//contar_coche(); //Vemos cuantos coches hay en el circuito

						insertado=true;
					}
				}
				if(!insertado) { //A lo mejor no se ha insertado el coche porque el coche que estaba antes ha tenido un accidente o ya ha terminado la carrera y no deja libre su carril hasta que termine completamente la carrera.
					System.out.println("En los carriles hay coches accidentados o coches que ya han acabado la carrera");
				}else {
					//**************
					vacio.signal(); //Se libera el proceso al frente de la cola porque se puede sacar un coche
					//**************
				}

			} finally {
				//**************
				lock.unlock(); //Desbloqueamos la seccion critica
				//**************
			}

		}
	}

	//Metodo por si quiere salir un coche del circuito antes de que empieze la carrera para que pueda asi entrar otro en su lugar
	public boolean sale_coche(){


		boolean eliminado = false;

		if(comienzoCarrera==false) { //Si no ha comenzado la carrera

			try {
				//**************
				lock.lock(); //Bloqueamos la seccion critica

				while (num_coches_actual == 0) { //Si no hay coches en el circuito no se pueden sacar coches
					try {
						vacio.await(); //Bloqueamo el proceso porque el circuito esta vacio
					} catch (InterruptedException e) {
					}
				}
				//**************

				int identificadorCoche;
				do{
					identificadorCoche = generarCocheQueAvanzaAleatorio(); //Sacamos el coche que avanza de manera aleatoria
				}while(getCoches()[identificadorCoche]==null);

				for(int i=0;i<getCoches().length && !eliminado;i++) {

					if( getCoches()[i]!=null && i==identificadorCoche ) {

						System.out.println("Coche"+getCoches()[i].getIdentificador()+" sale");

						num_coches_actual = num_coches_actual-1; //Decrementamos el numero de coches que hay en el circuito

						//contar_coche(); //Vemos cuantos coches hay en el circuito



						getCoches()[i] = null; //Vaciamos el sitio del array de coches

						eliminado=true;
					}
				}

				if(!eliminado) {
					System.out.println("El id del coche introducido no esta en el circuito!");
				}else {
					//**************
					lleno.signal();
					//**************
				}

				return eliminado;

			} finally {
				//**************
				lock.unlock(); //Desbloqueamos la seccion critica
				//**************
			}
		}
		return eliminado;
	}

	//Metodo por el cual sale un coche por accidente durante la carrera, no lo borra del array de coches para luego poder hacer la clasificacion, le pone el atributo de accidente a true, una vez termine la carrera borra el array para la siguiente
	public boolean sale_coche_por_accidente(int identificadorCoche) throws Exception_Circuito_Vacio {

		boolean accidente = false;

		if(num_coches_actual==0) { //Si no hay coches actuales, el circuito esta vacio

			throw new Exception_Circuito_Vacio();

		}else {

			for(int i=0;i<getCoches().length && !accidente;i++) {

				//El coche puede salir de la carrera si no ha salido anteriormente por un accidente, si no esta vacio y si coincide con el que tiene que salir
				if( getCoches()[i]!=null && getCoches()[i].isAccidente()==false && getCoches()[i].getIdentificador() == identificadorCoche) { 

					System.out.println("Coche"+getCoches()[i].getIdentificador()+" sale por accidente");

					num_coches_actual = num_coches_actual-1; //Decrementamos el numero de coches que hay en el circuito

					//contar_coche(); //Vemos cuantos coches hay en el circuito

					getCoches()[i].setAccidente(true); //Ponemos que el coche ha salido por un accidente

					accidente=true;
				}
			}

			if(!accidente) {
				System.out.println("El id del coche introducido no esta en el circuito!");
			}

		}

		return accidente;
	}

	public void start() throws InterruptedException, Exception_Circuito_Vacio {

		boolean accidenteGrave = false; //Al principio no ha ocurrido ningun accidente grave
		ArrayList<Coche> ganadores = new ArrayList<Coche>(); //Array donde vamos guardando los coches que han ido completando la carrera en orden

		comienzoCarrera=true; //Ha comenzado la carrera

		Thread.sleep(2000);
		System.out.println("Empieza la carrera");
		Thread.sleep(2000);

		while(num_coches_actual>0 && !accidenteGrave) {

			int cocheQueAvanza = generarCocheQueAvanzaAleatorio(); //Sacamos el coche que avanza de forma aleatoria entre los que hay
			Coche c = getCoches()[cocheQueAvanza];

			if(c!=null && !c.isAccidente() && !c.isTerminadoCarrera()) { //Vemos si el coche no es null y si no ha tenido un accidente y si no ha acabado la carrera

				avanzarCoche(c,ganadores);

				Thread.sleep(700);

				if(hay_accidente_grave() && num_coches_actual>0) { //Si ocurre un accidente y hay al menos un coche en el circuito

					//SONIDO ACCIDENTE GRAVE
					//*****************************************
					ReproducirSonido();
					//*****************************************

					accidente_grave();
					contar_coche();
					accidenteGrave = true;

					JOptionPane.showMessageDialog(frame_botones,
							"Ha ocurrido un accidente grave, todos los coches se retirar�n!", "Accidente-Grave",
							JOptionPane.INFORMATION_MESSAGE, null);
				}
			}
		}
		//Mostramos la clasificacion de los coches al terminar
		clasificacion(ganadores);

		//comienzoCarrera=false; //Ha terminado la carrera

		//setCoches(new Coche[filas]); //Cuando acabamos la carrera quedamos limpio el vector de los coches para la siguiente carrera
	}

	public void avanzarCoche(Coche c, ArrayList<Coche> ganadores) throws InterruptedException, Exception_Circuito_Vacio {

		c.setColumna(c.getColumna()+1); //Aumentamos la columna por la que va dicho coche
		System.out.println("Coche"+c.getIdentificador()+" en la posici�n ("+c.getFila()+","+c.getColumna()+")");

		if(c.getColumna()>=columnas) { //Si el coche ha llegado al final y no habia llegado antes guardamos que ha terminado la carrera
			c.setTerminadoCarrera(true); //El coche ha terminado la carrera

			ganadores.add(c); //A�adimos el coche al array list de ganadores para luego mostrarlo en la clasificacion

			System.out.println("El coche"+c.getIdentificador()+" ha terminado la carrera.");

			num_coches_actual = num_coches_actual-1; //Decrementamos el numero de coches que hay en el circuito porque ya ha terminado		

			contar_coche(); //Vemos cuantos coches hay en el circuito

			JOptionPane.showMessageDialog(frame_botones,
					"El coche "+c.getIdentificador()+" ha llegado a la meta", "Informaci�n",
					JOptionPane.INFORMATION_MESSAGE, null);

		}else { //Si no ha llegado al final

			Incidencia incidencia = getMatriz_coches()[c.getFila()][c.getColumna()]; //Sacamos la incidencia que le toca pasar al coche

			switch(incidencia.getNombreIncidencia()) {
			case "Nada":
				System.out.println("El coche"+c.getIdentificador()+" pasa a su velocidad.");
				break;

			case "Aceite":
				System.out.println("El coche"+c.getIdentificador()+" resvala por aceite (espera "+tiempoEspera/1000+"s).");
				Thread.sleep(tiempoEspera);
				break;

			case "Rueda":
				System.out.println("El coche"+c.getIdentificador()+" revienta una rueda (se retira).");
				sale_coche_por_accidente(c.getIdentificador());
				contar_coche();
				break;

			case "AccidenteLeve":
				System.out.println("Accidente Leve, todos los coches deben esperar "+tiempoEspera/1000+"s");
				Thread.sleep(tiempoEspera);
				break;

			default:
				System.out.println("El coche"+c.getIdentificador()+" est� en una incidencia desconocida.");
				break;
			}
		}
	}

	public void clasificacion(ArrayList<Coche> vector) {

		int posicion=1; //Guardamos la posicion que vamos poniendo de cada coche en orden
		System.out.println("\nCOCHES QUE HAN TERMINADO LA CARRERA");
		System.out.println("--------------------------------------");
		for(int i=0;i<vector.size();i++) {
			if(vector.get(i)!=null) {
				System.out.println("Posicion "+posicion+vector.get(i).toStringClasificacion());
				posicion++;
			}
		}
		System.out.println("--------------------------------------");

		System.out.println("\n--------------------------------------------------------------");

		System.out.println("\nCOCHES QUE HAN SALIDO POR UN ACCIDENTE");
		System.out.println("--------------------------------------");


		Coche[] ordenar_coches = new Coche[getCoches().length];
		for(int i=0;i<ordenar_coches.length;i++) {
			if(getCoches()[i]!=null) {
				ordenar_coches[i] = new Coche(getCoches()[i]);	
			}
		}

		ordenarCochesAccidentados(ordenar_coches);//Ordenamos el vector de los coches


		for(int i=0;i<ordenar_coches.length;i++) {
			if(ordenar_coches[i]!=null && ordenar_coches[i].isAccidente()==true) { //Si los coches han tenido un accidente
				System.out.println("Posicion "+posicion+ordenar_coches[i].toStringClasificacion());
				posicion++;
			}
		}
		System.out.println("--------------------------------------");

		System.out.println("\n----------------------------------------------------------------------------------------------------------------------------");	
	}

	//Metodo donde donde sacamos 1 aleatoria entre la probabilidad puesta y si es igual a probabilidad/probabilidad es que ocurre el accidente grave
	public boolean hay_accidente_grave() {
		int probabilidad = 50; //Vamos a poner que 1 de cada 50 hay un accidente grave, probabilidad del 2%
		boolean hayAccidente = false;

		int aleatorio = (int) (Math.random() * probabilidad);
		if(aleatorio == probabilidad/probabilidad) {
			hayAccidente = true;
		}

		return hayAccidente;
	}

	//Metodo que hace que todos los coches que no hayan salido ya de la carrera y que no la hayan terminado salgan de ella por un accidente grave
	public void accidente_grave() {
		System.out.println("Accidente Grave");

		for(int i=0;i<getCoches().length;i++) {

			//El coche saldra de la carrera si no ha salido anteriormente por un accidente y si no ha llegado todavia a la linea de meta y ha acabado la carrera
			if( getCoches()[i]!=null && getCoches()[i].isAccidente()==false && getCoches()[i].isTerminadoCarrera()==false) {

				System.out.println("Coche"+getCoches()[i].getIdentificador()+" sale por accidente grave");

				num_coches_actual = num_coches_actual-1; //Decrementamos el numero de coches que hay en el circuito

				getCoches()[i].setAccidente(true); //Ponemos que el coche ha salido por un accidente
			}
		}
		//contar_coche(); //Vemos cuantos coches hay en el circuito una vez de que salgan todos por accidente grave
	}

	//Genera de forma aleatoria el coche que va a avanzar por la matriz entre las filas que hay en la matriz(n� maximo de coches)
	public int generarCocheQueAvanzaAleatorio() {

		int aleatorio = (int) (Math.random() * filas);
		return aleatorio;
	}

	//Metodo para ordenar un array de coches para ordenarlo por el coche que mas columnas ha recorrido a al de menor columnas
	public void ordenarCochesAccidentados(Coche lista[]){

		//Usamos un bucle anidado
		for(int i=0;i<(lista.length-1);i++){
			for(int j=i+1;j<lista.length;j++){
				if(lista[i]!=null && lista[j]!=null && lista[i].getColumna()<lista[j].getColumna()){
					//Intercambiamos valores
					Coche variableauxiliar=lista[i];
					lista[i]=lista[j];
					lista[j]=variableauxiliar;
				}
			}
		}
	}

	public void ReproducirSonido() throws InterruptedException {
		Clip clip = null;

		try {
			AudioInputStream inputStream = AudioSystem.getAudioInputStream(new File("accidente_grave.wav"));
			DataLine.Info info = new DataLine.Info(Clip.class, inputStream.getFormat());
			clip = (Clip) AudioSystem.getLine(info);
			clip.open(inputStream);
			clip.start();
			Thread.sleep(1200);
			clip.stop();
		} catch (LineUnavailableException | IOException | UnsupportedAudioFileException ex) {
			ex.printStackTrace();
		}

	}

}