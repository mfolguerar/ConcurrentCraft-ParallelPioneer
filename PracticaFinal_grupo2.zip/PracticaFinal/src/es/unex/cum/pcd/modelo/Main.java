package es.unex.cum.pcd.modelo;

public class Main {

	public static void main(String[] args) throws InterruptedException, Exception_Circuito_Vacio{

		Circuito cir = new Circuito();

		new EntraCocheHilo(cir).start();
		new SalirCocheHilo(cir);
		new MostrarCocheHilo(cir);
	}
}
