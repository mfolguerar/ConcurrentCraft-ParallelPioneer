package es.unex.cum.pcd.modelo;

public class EjecutarCarrera  implements Runnable{
	private Thread lanzarCarrera;
	private Circuito cir;

	public EjecutarCarrera (Circuito c) {
		this.cir = c;
		lanzarCarrera = new Thread (this);
		lanzarCarrera.start(); 
	}

	public void run( ) {

		//Lanzamos la carrera 1 vez
		for(int i=0;i<1;i++) {
		
				try {
					cir.start();
				} catch (InterruptedException e) {
					
				} catch (Exception_Circuito_Vacio e) {
					
				}
		}
	}
}
