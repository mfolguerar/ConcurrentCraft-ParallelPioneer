package es.unex.cum.pcd.modelo;

//Ignacio Morcillo Pin
public class Coche {

	private int identificador; //Identificador del coche
	private String marca;
	private String motor;
	private int caballos;
	private String color;
	private float velocidad;
	private int fila; //Fila de la matriz donde se encuentra el coche
	private int columna; //Columna de la matriz donde se encuentra el coche
	private boolean accidente; //Atributo para controlar si el coche ha salido por accidente durante la carrera que le ha obligado a no continuar
	private boolean terminadoCarrera; //Atributo para controlar si el coche ha terminado la carrera hasta el final

	public Coche() {

		this.identificador = 0;
		this.marca = "";
		this.motor = "";
		this.caballos = 0;
		this.color = "";
		this.velocidad = 0.0F;
		this.fila = 0; //La fila de cada coche hay que a�adirla a posteriori
		this.columna = -1; //Al principio esta en la columna -1 porque no ha comenzado la carrera
		this.accidente = false; //Al principio de la carrera no ha tenido ningun accidente
		this.terminadoCarrera = false; //Al principio de la carrera no la ha terminado

	}
	
	public Coche(Coche c) {
		this.identificador = c.getIdentificador();
		this.marca = c.getMarca();
		this.motor = c.getMotor();
		this.caballos = c.getCaballos();
		this.color = c.getColor();
		this.velocidad = c.getVelocidad();
		this.fila = c.getFila();
		this.columna = c.getColumna();
		this.accidente = c.isAccidente(); //Al principio de la carrera no ha tenido ningun accidente
		this.terminadoCarrera = c.isTerminadoCarrera(); //Al principio de la carrera no la ha terminado
	}

	public Coche(int identificador, String marca, String motor, int caballos, String color, float velocidad, int fila, int columna) {

		this.identificador = identificador;
		this.marca = marca;
		this.motor = motor;
		this.caballos = caballos;
		this.color = color;
		this.velocidad = velocidad;
		this.fila = fila;
		this.columna = columna;
		this.accidente = false; //Al principio de la carrera no ha tenido ningun accidente
		this.terminadoCarrera = false; //Al principio de la carrera no la ha terminado
	}

	public int getIdentificador() {
		return identificador;
	}

	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getMotor() {
		return motor;
	}

	public void setMotor(String motor) {
		this.motor = motor;
	}

	public int getCaballos() {
		return caballos;
	}

	public void setCaballos(int caballos) {
		this.caballos = caballos;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public float getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(float velocidad) {
		this.velocidad = velocidad;
	}

	public int getFila() {
		return fila;
	}

	public void setFila(int fila) {
		this.fila = fila;
	}

	public int getColumna() {
		return columna;
	}

	public void setColumna(int columna) {
		this.columna = columna;
	}

	public boolean isAccidente() {
		return accidente;
	}

	public void setAccidente(boolean accidente) {
		this.accidente = accidente;
	}

	public boolean isTerminadoCarrera() {
		return terminadoCarrera;
	}

	public void setTerminadoCarrera(boolean terminadoCarrera) {
		this.terminadoCarrera = terminadoCarrera;
	}

	@Override
	public String toString() {
		return "Coche [identificador=" + identificador + ", marca=" + marca + ", motor=" + motor + ", caballos="
				+ caballos + ", color=" + color + ", velocidad=" + velocidad + ", fila=" + fila + ", columna=" + columna
				+ ", accidente=" + accidente + ", terminadoCarrera=" + terminadoCarrera + "]";
	}

	public String toStringClasificacion() {
		return " Coche" + identificador + " Fila:" + fila + " Columna:" + columna;
	}

}
