package es.unex.cum.pcd.modelo;

public class EntraCocheHilo extends Thread{
	private Circuito cir;

	public EntraCocheHilo (Circuito c) {
		this.cir = c;
	}

	public void run( ) {

		while(true) {

			try {

				cir.entra_coche();

				//Ponemos un tiempo de espera aleatorio
				int tiempo_maximo = 2000;
				int tiempo_minimo = 800;
				int tiempo_aleatorio = tiempo_maximo - tiempo_minimo + 1;
				int random = (int) (Math.random() * tiempo_aleatorio) + tiempo_minimo;

				sleep(random);

			} catch (InterruptedException e) {

			}
		}
	}
}