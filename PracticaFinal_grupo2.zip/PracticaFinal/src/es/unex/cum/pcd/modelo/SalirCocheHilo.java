package es.unex.cum.pcd.modelo;

public class SalirCocheHilo implements Runnable{
	
	private Thread hiloSaleCoche;
	private Circuito cir;

	public SalirCocheHilo (Circuito c) {
		this.cir = c;
		hiloSaleCoche = new Thread (this);
		hiloSaleCoche.start();
	}

	public void run( ) {

		while(true) {
			try {
				cir.sale_coche();
				
				int max_sleep = 2000;
				int min_sleep = 800;
				int range_sleep = max_sleep - min_sleep + 1;
				int rand_sleep = (int) (Math.random() * range_sleep) + min_sleep;
				
				Thread.sleep (rand_sleep);
			} catch (InterruptedException e) { 
				return; 
			}
		}
	}
}