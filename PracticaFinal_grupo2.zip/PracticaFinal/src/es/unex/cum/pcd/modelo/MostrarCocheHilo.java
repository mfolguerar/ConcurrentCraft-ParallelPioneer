package es.unex.cum.pcd.modelo;

import es.unex.cum.pcd.practica.Main_Interfaz;

public class MostrarCocheHilo implements Runnable{ 
	private Thread hiloContarCoche;
	private Circuito p;

	public MostrarCocheHilo (Circuito c) {
		this.p = c;
		hiloContarCoche = new Thread (this);
		hiloContarCoche.start(); 
	}

	public void run( ) {

		while (true) {

			//Mostramos la interfaz del circuito en tiempo real
			Main_Interfaz.crear_Circuito(p.getCoches(), p.getMatriz_coches(), p.getFrame_botones(), p.getButton(), p.getMatriz_coches().length,
					p.getMatriz_coches()[0].length);

			p.contar_coche();
		}
	}
}