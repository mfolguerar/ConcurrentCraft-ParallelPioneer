package es.unex.cum.pcd.practica;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import es.unex.cum.pcd.modelo.Circuito;
import es.unex.cum.pcd.modelo.Coche;
import es.unex.cum.pcd.modelo.EjecutarCarrera;
import es.unex.cum.pcd.modelo.EntraCocheHilo;
import es.unex.cum.pcd.modelo.Incidencia;
import es.unex.cum.pcd.modelo.MostrarCocheHilo;
import es.unex.cum.pcd.modelo.SalirCocheHilo;


public class Main_Interfaz extends JFrame {

	private static final long serialVersionUID = 1L;

	private Circuito p;

	private JPanel contentPane;

	JTable jtable;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main_Interfaz frame = new Main_Interfaz();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public static void crear_Circuito(Coche[] coches, Incidencia[][] matriz, JFrame frame_botones, JButton[][] button, int fil, int col) {

		//Recorremos todas las filas que hacen referencia a los coches que tenemos
		//Recorremos solo una columna que es la que hace referencia a la posicion inicial del coche
		//FILAS
		for(int i=0;i<fil;i++) {
			//COLUMNAS SOLO LA 0
			for(int j=0;j<1;j++) {


				if(coches[i]!=null && coches[i].getColumna()==-1 && coches[i].isTerminadoCarrera()==false && coches[i].isAccidente()==false) {
					switch(i) {
					case 0:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_azul.png")));
						break;
					case 1:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_crema.png")));
						break;
					case 2:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_granate.png")));
						break;
					case 3:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_marron.png")));
						break;
					case 4:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_naranja.png")));
						break;
					case 5:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_negro.png")));
						break;
					case 6:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rojo.png")));
						break;
					case 7:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rosa_claro.png")));
						break;
					case 8:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rosa.png")));
						break;
					case 9:
						button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_verde.png")));
						break;
					}	
				}else {
					button[i][j].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/nada.png")));
				}	
			}
		}

		for (int i = 0; i < fil; i++) {
			for (int j = 0; j < col; j++) {

				if(coches[i]!=null && coches[i].getColumna()==col && coches[i].isTerminadoCarrera()==true && coches[i].isAccidente()==false) {

					switch(i) {
					case 0:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_azul.png")));
						break;
					case 1:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_crema.png")));
						break;
					case 2:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_granate.png")));
						break;
					case 3:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_marron.png")));
						break;
					case 4:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_naranja.png")));
						break;
					case 5:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_negro.png")));
						break;
					case 6:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rojo.png")));
						break;
					case 7:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rosa_claro.png")));
						break;
					case 8:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rosa.png")));
						break;
					case 9:
						button[i][col].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_verde.png")));
						break;

					}	

				}else if(coches[i]!=null && coches[i].getColumna()==j && coches[i].isAccidente()==false && coches[i].isTerminadoCarrera()==false) { //Entonces es que el coche esta en una posicion de la matriz incidencia
					switch(i) {
					case 0:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_azul.png")));
						break;
					case 1:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_crema.png")));
						break;
					case 2:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_granate.png")));
						break;
					case 3:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_marron.png")));
						break;
					case 4:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_naranja.png")));
						break;
					case 5:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_negro.png")));
						break;
					case 6:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rojo.png")));
						break;
					case 7:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rosa_claro.png")));
						break;
					case 8:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_rosa.png")));
						break;
					case 9:
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/coche_verde.png")));
						break;
					}	
				}else {
					switch(matriz[i][j].getNombreIncidencia()) {
					case "Nada":
						button[i][j+1].setFocusable(false);
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/nada.png")));

						break;
					case "Aceite":
						button[i][j+1].setFocusable(false);
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/aceite.png")));

						break;
					case "Rueda":
						button[i][j+1].setFocusable(false);
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/rueda.png")));

						break;
					case "AccidenteLeve":
						button[i][j+1].setFocusable(false);
						button[i][j+1].setIcon(new ImageIcon(Main_Interfaz.class.getResource("../imagenes/accidente_leve.png")));

						break;
					}
				}

				frame_botones.pack();
				frame_botones.setVisible(true);

			}
		}
	}

	public Main_Interfaz() {
		setTitle("PR\u00C1CTICA FINAL - CIRCUITO");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Main_Interfaz.class.getResource("/es/unex/cum/pcd/imagenes/icono_bandera.png")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 703, 499);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu mnMenu_CrearCircuito = new JMenu("Crear Circuito");
		mnMenu_CrearCircuito.setFont(new Font("Segoe UI", Font.BOLD, 12));
		menuBar.add(mnMenu_CrearCircuito);

		JMenu mnMenuAyuda = new JMenu("Ayuda");
		mnMenuAyuda.setFont(new Font("Segoe UI", Font.BOLD, 12));
		menuBar.add(mnMenuAyuda);

		JMenuItem mntmInformacion = new JMenuItem("Informaci\u00F3n");
		mntmInformacion.setFont(new Font("Segoe UI", Font.BOLD, 12));
		mntmInformacion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Toolkit.getDefaultToolkit().beep();
				JOptionPane.showMessageDialog(rootPane,
						"Pr�ctica Final PCD - Curso 2021-2022\n\nHecho por:\n-Ignacio Morcillo Pin\n-F�lix Parra Molinero\n-Marcos Folguera Rivera", "Informaci�n",
						JOptionPane.INFORMATION_MESSAGE, null);
			}
		});
		mnMenuAyuda.add(mntmInformacion);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnInsertarCoche = new JButton("A\u00F1adir coche");
		btnInsertarCoche.setBackground(Color.BLACK);
		btnInsertarCoche.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnInsertarCoche.setForeground(Color.YELLOW);
		btnInsertarCoche.setVisible(false);
		btnInsertarCoche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p.entra_coche();
			}
		});

		JButton btnSacarCoche = new JButton("Sacar Coche");
		btnSacarCoche.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnSacarCoche.setForeground(Color.YELLOW);
		btnSacarCoche.setBackground(Color.BLACK);
		btnSacarCoche.setVisible(false);
		btnSacarCoche.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				p.sale_coche();
			}
		});

		JButton btnComenzarCarrera = new JButton("Comenzar Carrera");
		btnComenzarCarrera.setForeground(Color.YELLOW);
		btnComenzarCarrera.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnComenzarCarrera.setBackground(Color.BLACK);
		btnComenzarCarrera.setVisible(false);
		btnComenzarCarrera.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//Creamos el hilo y lo lanzamos para empezar la carrera de un determinado circuito
				new EjecutarCarrera(p);
			}
		});

		JLabel lblDatosCircuito = new JLabel("Datos del circuito:");
		lblDatosCircuito.setForeground(Color.WHITE);
		lblDatosCircuito.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblDatosCircuito.setBounds(284, 97, 206, 53);
		contentPane.add(lblDatosCircuito);

		JLabel lblColumnas = new JLabel("(columnas)");
		lblColumnas.setForeground(Color.WHITE);
		lblColumnas.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblColumnas.setBounds(177, 237, 122, 35);
		contentPane.add(lblColumnas);

		JLabel lblFilas = new JLabel("(filas)");
		lblFilas.setForeground(Color.WHITE);
		lblFilas.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblFilas.setBounds(196, 178, 67, 35);
		contentPane.add(lblFilas);

		JLabel lblIntroduceColumnas = new JLabel("Introduce n\u00FAmero de kil\u00F3metros:");
		lblIntroduceColumnas.setForeground(Color.WHITE);
		lblIntroduceColumnas.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblIntroduceColumnas.setBounds(66, 211, 318, 35);
		contentPane.add(lblIntroduceColumnas);

		JLabel lblIntroduceFilas = new JLabel("Introduce n\u00FAmero de carriles:");
		lblIntroduceFilas.setForeground(Color.WHITE);
		lblIntroduceFilas.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblIntroduceFilas.setBounds(93, 150, 291, 35);
		contentPane.add(lblIntroduceFilas);
		btnComenzarCarrera.setBounds(303, 388, 187, 35);
		contentPane.add(btnComenzarCarrera);
		btnSacarCoche.setBounds(148, 388, 131, 35);
		contentPane.add(btnSacarCoche);
		btnInsertarCoche.setBounds(10, 388, 131, 35);
		contentPane.add(btnInsertarCoche);

		JComboBox comboBox_filas = new JComboBox();
		comboBox_filas.setMaximumRowCount(5);
		comboBox_filas.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBox_filas.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		comboBox_filas.setSelectedIndex(0);
		comboBox_filas.setBounds(424, 159, 112, 21);
		contentPane.add(comboBox_filas);

		JComboBox comboBox_columnas = new JComboBox();
		comboBox_columnas.setMaximumRowCount(5);
		comboBox_columnas.setFont(new Font("Tahoma", Font.PLAIN, 16));
		comboBox_columnas.setModel(new DefaultComboBoxModel(new String[] {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		comboBox_columnas.setSelectedIndex(0);
		comboBox_columnas.setBounds(424, 220, 112, 21);
		contentPane.add(comboBox_columnas);

		JLabel lblFondoPrincipal = new JLabel("");
		lblFondoPrincipal.setIcon(new ImageIcon(Main_Interfaz.class.getResource("/es/unex/cum/pcd/imagenes/fondo_principal.png")));
		lblFondoPrincipal.setBounds(0, 0, 700, 451);
		contentPane.add(lblFondoPrincipal);

		JMenuItem mntm_Crear = new JMenuItem("Crear");
		mntm_Crear.setFont(new Font("Segoe UI", Font.BOLD, 12));
		mntm_Crear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				//Cogemos las filas que elegimos
				int fil = Integer.parseInt(comboBox_filas.getSelectedItem().toString());

				//Cogemos las columnas que elegimos
				int col = Integer.parseInt(comboBox_columnas.getSelectedItem().toString());

				//Creamos el circuito en si
				p = new Circuito(fil, col);

				//Creamos el hilo para mostrar los coches
				new MostrarCocheHilo(p);
				
				//Creamos el hilo para entrar los coches
				new EntraCocheHilo(p).start();
				
				//Creamos el hilo para salir los coches
				new SalirCocheHilo(p);
				
				btnInsertarCoche.setVisible(true);
				btnSacarCoche.setVisible(true);
				btnComenzarCarrera.setVisible(true);
				
			}
		});
		mnMenu_CrearCircuito.add(mntm_Crear);

	}
}
